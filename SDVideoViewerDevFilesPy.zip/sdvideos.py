import cv2
import json
import numpy as np
from PIL import Image
import zlib
import os
import base64
import argparse

# Function to convert PNG to SDIMG format with hex encoding
def png_to_sdimg(input_png, output_sdimg, compression_level=9, color_type="rgba"):
    # Open PNG image
    img = Image.open(input_png)
    width, height = img.size
    pixels = img.load()

    # Prepare pixel data in the desired format (either RGB or HEX)
    print("Generating pixel data...")
    pixel_data = {}
    for y in range(height):
        for x in range(width):
            # Extract RGBA or RGB based on image mode
            pixel = img.getpixel((x, y))
            if len(pixel) == 4:  # RGBA image
                r, g, b, a = pixel
            elif len(pixel) == 3:  # RGB image, no alpha channel
                r, g, b = pixel
                a = 255  # Default alpha to 255 (fully opaque)

            if color_type == "hex":
                # Convert RGBA to hex format
                hex_value = f"#{r:02x}{g:02x}{b:02x}{a:02x}"
                pixel_data[f"{x+1}x{y+1}"] = {"hex": hex_value}
            else:
                # Use RGBA format
                pixel_data[f"{x+1}x{y+1}"] = {"r": r, "g": g, "b": b, "a": a}

    print("Pixel Data generated.")
    # Construct the JSON structure
    image_data = {
        "colortype": color_type,
        "comp_level": compression_level,
        "pixels": pixel_data,
        "width": width,
        "height": height
    }

    # Convert to JSON and compress
    json_data = json.dumps(image_data)
    compressed_data = zlib.compress(json_data.encode('utf-8'), level=compression_level)

    # Base64 encode the compressed data and write to file
    base64_encoded = base64.b64encode(compressed_data).decode('utf-8')
    with open(output_sdimg, 'w') as f:
        f.write(base64_encoded)

    print(f"Image saved as {output_sdimg} with compression level {compression_level}")

# Function to convert SDIMG back to PNG format (as used in previous code)
def sdimg_to_png(input_sdimg, output_png):
    # Read the SDIMG file and decode base64 data
    with open(input_sdimg, 'r') as f:
        base64_encoded_data = f.read()

    # Decode base64 and decompress
    compressed_data = base64.b64decode(base64_encoded_data)
    json_data = zlib.decompress(compressed_data).decode('utf-8')

    # Parse the JSON data
    image_data = json.loads(json_data)

    # Extract pixel data and metadata
    width = image_data['width']
    height = image_data['height']
    color_type = image_data['colortype']
    pixels = image_data['pixels']

    # Create a new image
    img = Image.new("RGBA", (width, height))

    # Set the pixel data
    for y in range(height):
        for x in range(width):
            pixel_key = f"{x+1}x{y+1}"
            if color_type == "hex":
                hex_value = pixels[pixel_key]["hex"]
                img.putpixel((x, y), tuple(int(hex_value[i:i+2], 16) for i in (1, 3, 5, 7)))
            else:
                r = pixels[pixel_key]["r"]
                g = pixels[pixel_key]["g"]
                b = pixels[pixel_key]["b"]
                a = pixels[pixel_key]["a"]
                img.putpixel((x, y), (r, g, b, a))

    # Save the image as PNG
    img.save(output_png, "PNG")
    print(f"Image saved as {output_png}")

# Function to convert SDVID back to MP4 format
def sdvid_to_mp4(input_sdvid, output_mp4, fps=30):
    # Read the SDVID file and decompress the frames data
    with open(input_sdvid, 'rb') as f:
        compressed_data = f.read()
    
    frames_data = zlib.decompress(compressed_data).decode('utf-8')
    frames = json.loads(frames_data)

    # Get the video dimensions (assuming all frames are the same size)
    width = frames[0]["width"]
    height = frames[0]["height"]

    # Create the video writer object
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_mp4, fourcc, fps, (width, height))

    # Process each frame in the SDVID and convert it back to an image
    for frame_data in frames:
        # Convert frame data back to SDIMG (temporarily save to PNG for conversion)
        temp_sdimg = "temp_frame.sdimg"
        with open(temp_sdimg, 'w') as f:
            base64_encoded = base64.b64encode(zlib.compress(json.dumps(frame_data).encode())).decode('utf-8')
            f.write(base64_encoded)

        # Convert the SDIMG frame to PNG
        temp_png = "temp_frame.png"
        sdimg_to_png(temp_sdimg, temp_png)

        # Read the PNG back into OpenCV
        frame = cv2.imread(temp_png)
        
        # Write the frame to the video
        out.write(frame)

        # Clean up temporary files
        os.remove(temp_sdimg)
        os.remove(temp_png)

    # Release the video writer and finalize the MP4 file
    out.release()

    print(f"MP4 file saved as {output_mp4}")

# Convert MP4 to SDVID format with FPS Limiting
def mp4_to_sdvid(input_mp4, output_sdvid, compression_level=9, color_type="rgba", fps=30):
    # Open the video file using OpenCV
    cap = cv2.VideoCapture(input_mp4)
    
    if not cap.isOpened():
        print(f"Error: Could not open video {input_mp4}")
        return

    frames = []
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    print(f"Converting {frame_count} frames from {input_mp4}...")

    # Get the actual FPS of the video
    video_fps = cap.get(cv2.CAP_PROP_FPS)
    print(f"Video FPS: {video_fps}")

    # Calculate the interval for selecting frames based on the desired fps
    frame_interval = int(round(video_fps / fps))  # Correct FPS adjustment

    if frame_interval < 1:
        frame_interval = 1  # Ensure that we don't skip all frames

    print(f"Frame interval for FPS {fps}: {frame_interval} frames")

    # Temporary directory for saving individual frame SDIMG files
    temp_dir = "temp_frames"
    os.makedirs(temp_dir, exist_ok=True)

    # Read each frame, convert it to a PNG file, then to SDIMG format
    for i in range(frame_count):
        ret, frame = cap.read()
        if not ret:
            break

        # Skip frames to match the desired fps
        if i % frame_interval != 0:
            continue

        # Convert the frame to a PIL Image for processing
        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

        # Save the frame as a PNG file temporarily
        temp_png = f"{temp_dir}/frame_{i:04d}.png"
        img.save(temp_png)

        # Convert the PNG frame to SDIMG format
        temp_sdimg = f"{temp_dir}/frame_{i:04d}.sdimg"
        png_to_sdimg(temp_png, temp_sdimg, compression_level, color_type)

        # Read the SDIMG file and extract the hex values
        with open(temp_sdimg, 'r') as f:
            base64_encoded_data = f.read()
        
        # Decode base64 and decompress the SDIMG data
        compressed_data = base64.b64decode(base64_encoded_data)
        json_data = zlib.decompress(compressed_data).decode('utf-8')
        
        # Parse the JSON data
        image_data = json.loads(json_data)

        # Extract hex data for frames
        frames.append(image_data)

        # Clean up temporary PNG and SDIMG files
        os.remove(temp_png)
        os.remove(temp_sdimg)

    cap.release()

    # Apply compression for the SDVID file
    compressed_frames = zlib.compress(json.dumps(frames).encode(), compression_level)

    # Prepare the SDVID data
    video_data = {
        "frames": frames,
        "compression_level": compression_level,
        "colortype": color_type,
        "width": width,
        "height": height,
        "frame_count": len(frames),  # Use the actual number of frames saved
        "fps": fps  # Add the fps value
    }

    # Save the SDVID file
    with open(output_sdvid, 'wb') as f:
        f.write(compressed_frames)

    print(f"SDVID file saved as {output_sdvid}")
    # Clean up the temporary directory
    os.rmdir(temp_dir)

def sdvid_to_webm(input_sdvid, output_webm, fps=30):
    # Read the SDVID file and decompress the frames data
    with open(input_sdvid, 'rb') as f:
        compressed_data = f.read()
    
    frames_data = zlib.decompress(compressed_data).decode('utf-8')
    frames = json.loads(frames_data)

    # Get the video dimensions (assuming all frames are the same size)
    width = frames[0]["width"]
    height = frames[0]["height"]

    # Create the video writer object for WebM format (VP8 codec)
    fourcc = cv2.VideoWriter_fourcc(*'vp80')
    out = cv2.VideoWriter(output_webm, fourcc, fps, (width, height))

    # Process each frame in the SDVID and convert it back to an image
    for i, frame_data in enumerate(frames):
        # Convert frame data back to SDIMG (temporarily save to a file)
        temp_sdimg = "temp_frame.sdimg"
        with open(temp_sdimg, 'w') as f:
            base64_encoded = base64.b64encode(zlib.compress(json.dumps(frame_data).encode())).decode('utf-8')
            f.write(base64_encoded)

        # Convert the SDIMG frame to PNG
        temp_png = "temp_frame.png"
        sdimg_to_png(temp_sdimg, temp_png)

        # Read the PNG back into OpenCV
        frame = cv2.imread(temp_png)

        if frame is not None:
            # Write the frame to the video
            out.write(frame)
        else:
            print(f"Warning: Could not read the PNG for frame {i}.")

        # Clean up temporary files
        os.remove(temp_sdimg)
        os.remove(temp_png)

    # Release the video writer and finalize the WebM file
    out.release()

    print(f"WebM file saved as {output_webm}")

def webm_to_sdvid(input_video, output_sdvid, compression_level=9, color_type="rgba", fps=30):
    # Open the video file using OpenCV
    cap = cv2.VideoCapture(input_video)
    
    if not cap.isOpened():
        print(f"Error: Could not open video {input_video}")
        return

    frames = []
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    print(f"Converting {frame_count} frames from {input_video}...")

    # Get the actual FPS of the video
    video_fps = cap.get(cv2.CAP_PROP_FPS)
    print(f"Video FPS: {video_fps}")

    # Calculate the interval for selecting frames based on the desired fps
    frame_interval = int(round(video_fps / fps))  # Correct FPS adjustment

    if frame_interval < 1:
        frame_interval = 1  # Ensure that we don't skip all frames

    print(f"Frame interval for FPS {fps}: {frame_interval} frames")

    # Temporary directory for saving individual frame SDIMG files
    temp_dir = "temp_frames"
    os.makedirs(temp_dir, exist_ok=True)

    # Read each frame, convert it to a PNG file, then to SDIMG format
    for i in range(frame_count):
        ret, frame = cap.read()
        if not ret:
            break

        # Skip frames to match the desired fps
        if i % frame_interval != 0:
            continue

        # Convert the frame to a PIL Image for processing
        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

        # Save the frame as a PNG file temporarily
        temp_png = f"{temp_dir}/frame_{i:04d}.png"
        img.save(temp_png)

        # Convert the PNG frame to SDIMG format
        temp_sdimg = f"{temp_dir}/frame_{i:04d}.sdimg"
        png_to_sdimg(temp_png, temp_sdimg, compression_level, color_type)

        # Read the SDIMG file and extract the hex values
        with open(temp_sdimg, 'r') as f:
            base64_encoded_data = f.read()
        
        # Decode base64 and decompress the SDIMG data
        compressed_data = base64.b64decode(base64_encoded_data)
        json_data = zlib.decompress(compressed_data).decode('utf-8')
        
        # Parse the JSON data
        image_data = json.loads(json_data)

        # Extract hex data for frames
        frames.append(image_data)

        # Clean up temporary PNG and SDIMG files
        os.remove(temp_png)
        os.remove(temp_sdimg)

    cap.release()

    # Apply compression for the SDVID file
    compressed_frames = zlib.compress(json.dumps(frames).encode(), compression_level)

    # Prepare the SDVID data
    video_data = {
        "frames": frames,
        "compression_level": compression_level,
        "colortype": color_type,
        "width": width,
        "height": height,
        "frame_count": len(frames),  # Use the actual number of frames saved
        "fps": fps  # Add the fps value
    }

    # Save the SDVID file
    with open(output_sdvid, 'wb') as f:
        f.write(compressed_frames)

    print(f"SDVID file saved as {output_sdvid}")

    # Clean up the temporary directory
    for temp_file in os.listdir(temp_dir):
        os.remove(os.path.join(temp_dir, temp_file))
    os.rmdir(temp_dir)

# Command-line interface for the script using subcommands
def main():
    parser = argparse.ArgumentParser(description="Convert MP4 to SDVID and vice versa.")

    subparsers = parser.add_subparsers(dest="command")

    # Subcommand for converting MP4 to SDVID
    mp4_to_sdvid_parser = subparsers.add_parser("mp4-to-sdvid", help="Convert MP4 file to SDVID format.")
    mp4_to_sdvid_parser.add_argument("input_mp4", help="Input MP4 file path")
    mp4_to_sdvid_parser.add_argument("output_sdvid", help="Output SDVID file path")
    mp4_to_sdvid_parser.add_argument("--compression", type=int, default=9, help="Compression level (0-9)")
    mp4_to_sdvid_parser.add_argument("--colortype", choices=["rgba", "rgb"], default="rgba", help="Color format")
    mp4_to_sdvid_parser.add_argument("--fps", type=int, default=30, help="Frames per second")

    # Subcommand for converting SDVID to MP4
    sdvid_to_mp4_parser = subparsers.add_parser("sdvid-to-mp4", help="Convert SDVID file to MP4 format.")
    sdvid_to_mp4_parser.add_argument("input_sdvid", help="Input SDVID file path")
    sdvid_to_mp4_parser.add_argument("output_mp4", help="Output MP4 file path")


    # Subcommand for converting MP4 to SDVID
    webm_to_sdvid_parser = subparsers.add_parser("webm-to-sdvid", help="Convert WebM file to SDVID format.")
    webm_to_sdvid_parser.add_argument("input_webm", help="Input WebM file path")
    webm_to_sdvid_parser.add_argument("output_sdvid", help="Output SDVID file path")
    webm_to_sdvid_parser.add_argument("--compression", type=int, default=9, help="Compression level (0-9)")
    webm_to_sdvid_parser.add_argument("--colortype", choices=["rgba", "rgb"], default="rgba", help="Color format")
    webm_to_sdvid_parser.add_argument("--fps", type=int, default=30, help="Frames per second")

    # Subcommand for converting SDVID to MP4
    sdvid_to_webm_parser = subparsers.add_parser("sdvid-to-webm", help="Convert SDVID file to WebM format.")
    sdvid_to_webm_parser.add_argument("input_sdvid", help="Input SDVID file path")
    sdvid_to_webm_parser.add_argument("output_webm", help="Output WebM file path")

    args = parser.parse_args()

    # Execute appropriate function based on subcommand
    if args.command == "mp4-to-sdvid":
        mp4_to_sdvid(args.input_mp4, args.output_sdvid, args.compression, args.colortype, args.fps)
    elif args.command == "sdvid-to-mp4":
        sdvid_to_mp4(args.input_sdvid, args.output_mp4)
    elif args.command == "webm-to-sdvid":
        mp4_to_sdvid(args.input_webm, args.output_sdvid, args.compression, args.colortype, args.fps)
    elif args.command == "sdvid-to-webm":
        sdvid_to_webm(args.input_sdvid, args.output_webm)
    else:
        print("Unknown command.")

if __name__ == "__main__":
    main()
